This file is the "Assembly" of all the parts needed to print. I left out the model of the Raspberry PI due to licensing. If you need the raspberry pi model, do a search on GrabCad there are a ton!
