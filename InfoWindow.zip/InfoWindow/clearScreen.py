from mod_infowindow import infowindow
iw = infowindow.InfoWindow()
iw.display()
